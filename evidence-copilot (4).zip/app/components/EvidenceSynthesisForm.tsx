"use client"

import type React from "react"
import { useState } from "react"
import { ChevronLeft } from "lucide-react"
import Tooltip from "./Tooltip"

type EvidenceSynthesisFormProps = {
  selectedSubcategory: string
}

const EvidenceSynthesisForm: React.FC<EvidenceSynthesisFormProps> = ({ selectedSubcategory }) => {
  const [selectedDatabases, setSelectedDatabases] = useState<string[]>([])
  const [otherDatabases, setOtherDatabases] = useState("")
  const [yearRangeStart, setYearRangeStart] = useState("")
  const [yearRangeEnd, setYearRangeEnd] = useState("")
  const [languages, setLanguages] = useState("")
  const [studyTypes, setStudyTypes] = useState<string[]>([])
  const [otherStudyTypes, setOtherStudyTypes] = useState("")
  const [qualityAssessmentTool, setQualityAssessmentTool] = useState("")
  const [heterogeneityAssessment, setHeterogeneityAssessment] = useState("")
  const [publicationBiasAssessment, setPublicationBiasAssessment] = useState("")
  const [indirectComparisonMethod, setIndirectComparisonMethod] = useState("")
  const [reportingGuidelines, setReportingGuidelines] = useState<string[]>([])
  const [otherReportingGuidelines, setOtherReportingGuidelines] = useState("")

  const renderSubcategorySpecificFields = () => {
    switch (selectedSubcategory) {
      case "systematic-review":
        return (
          <div className="space-y-4 border p-4 rounded-md bg-gray-50">
            <h4 className="font-medium text-gray-800">Systematic Review Specific Details</h4>

            <div>
              <label htmlFor="screening-process" className="block text-sm font-medium text-gray-700 mb-1">
                Screening Process
                <Tooltip content="Describe the process for screening and selecting studies, including number of reviewers and resolution of disagreements." />
              </label>
              <textarea
                id="screening-process"
                placeholder="E.g., Two independent reviewers will screen titles and abstracts, followed by full-text review of potentially eligible studies. Disagreements will be resolved by consensus or a third reviewer."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="data-extraction" className="block text-sm font-medium text-gray-700 mb-1">
                Data Extraction Method
                <Tooltip content="Describe how data will be extracted from included studies and what information will be collected." />
              </label>
              <textarea
                id="data-extraction"
                placeholder="E.g., A standardized data extraction form will be used to collect study characteristics, participant demographics, intervention details, outcomes, and results. Two reviewers will independently extract data."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="narrative-synthesis" className="block text-sm font-medium text-gray-700 mb-1">
                Narrative Synthesis Approach
                <Tooltip content="Describe how findings will be synthesized qualitatively if meta-analysis is not possible or appropriate." />
              </label>
              <textarea
                id="narrative-synthesis"
                placeholder="E.g., Results will be organized by outcome and study design. Similarities and differences across studies will be explored and possible explanations for discrepancies will be discussed."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        )

      case "meta-analysis":
        return (
          <div className="space-y-4 border p-4 rounded-md bg-gray-50">
            <h4 className="font-medium text-gray-800">Meta-Analysis Specific Details</h4>

            <div>
              <label htmlFor="effect-measure" className="block text-sm font-medium text-gray-700 mb-1">
                Effect Measure
                <Tooltip content="Specify the effect measure that will be used for the meta-analysis." />
              </label>
              <div className="relative">
                <select
                  id="effect-measure"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="" disabled>
                    Select effect measure
                  </option>
                  <option value="odds-ratio">Odds Ratio (OR)</option>
                  <option value="risk-ratio">Risk Ratio (RR)</option>
                  <option value="hazard-ratio">Hazard Ratio (HR)</option>
                  <option value="risk-difference">Risk Difference (RD)</option>
                  <option value="mean-difference">Mean Difference (MD)</option>
                  <option value="std-mean-difference">Standardized Mean Difference (SMD)</option>
                  <option value="rate-ratio">Rate Ratio</option>
                  <option value="correlation">Correlation Coefficient</option>
                  <option value="other">Other</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <ChevronLeft className="h-4 w-4 text-gray-400 rotate-180" />
                </div>
              </div>
            </div>

            <div>
              <label htmlFor="statistical-model" className="block text-sm font-medium text-gray-700 mb-1">
                Statistical Model
                <Tooltip content="Specify the statistical model that will be used for combining study results." />
              </label>
              <div className="relative">
                <select
                  id="statistical-model"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="" disabled>
                    Select statistical model
                  </option>
                  <option value="fixed-effects">Fixed-Effects Model</option>
                  <option value="random-effects">Random-Effects Model</option>
                  <option value="mixed-effects">Mixed-Effects Model</option>
                  <option value="bayesian">Bayesian Model</option>
                  <option value="other">Other</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <ChevronLeft className="h-4 w-4 text-gray-400 rotate-180" />
                </div>
              </div>
            </div>

            <div>
              <label htmlFor="subgroup-analyses" className="block text-sm font-medium text-gray-700 mb-1">
                Planned Subgroup Analyses
                <Tooltip content="Describe any pre-planned subgroup analyses that will be conducted." />
              </label>
              <textarea
                id="subgroup-analyses"
                placeholder="E.g., Subgroup analyses will be conducted based on: 1) patient population characteristics (age, gender, disease severity), 2) intervention variations (dose, duration), and 3) study design features (randomization method, blinding)."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="sensitivity-analyses" className="block text-sm font-medium text-gray-700 mb-1">
                Planned Sensitivity Analyses
                <Tooltip content="Describe any sensitivity analyses that will be conducted to test the robustness of results." />
              </label>
              <textarea
                id="sensitivity-analyses"
                placeholder="E.g., Sensitivity analyses will be conducted by: 1) excluding studies with high risk of bias, 2) using different statistical models, 3) excluding outliers, and 4) using different effect measures."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        )

      case "network-meta-analysis":
        return (
          <div className="space-y-4 border p-4 rounded-md bg-gray-50">
            <h4 className="font-medium text-gray-800">Network Meta-Analysis Specific Details</h4>

            <div>
              <label htmlFor="network-geometry" className="block text-sm font-medium text-gray-700 mb-1">
                Network Geometry
                <Tooltip content="Describe how the network of treatment comparisons will be constructed and visualized." />
              </label>
              <textarea
                id="network-geometry"
                placeholder="E.g., The network will be constructed using all direct and indirect comparisons between included interventions. Network geometry will be visualized using network plots generated with the 'netmeta' package in R."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="consistency-assessment" className="block text-sm font-medium text-gray-700 mb-1">
                Consistency Assessment
                <Tooltip content="Describe how the assumption of consistency will be assessed in the network meta-analysis." />
              </label>
              <textarea
                id="consistency-assessment"
                placeholder="E.g., Consistency between direct and indirect evidence will be assessed using node-splitting models and the design-by-treatment interaction model. Local inconsistency will be evaluated by comparing direct and indirect estimates for each comparison."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="ranking-method" className="block text-sm font-medium text-gray-700 mb-1">
                Treatment Ranking Method
                <Tooltip content="Specify how treatments will be ranked in terms of their relative efficacy or safety." />
              </label>
              <div className="relative">
                <select
                  id="ranking-method"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="" disabled>
                    Select ranking method
                  </option>
                  <option value="sucra">Surface Under the Cumulative Ranking Curve (SUCRA)</option>
                  <option value="p-best">Probability of Being the Best</option>
                  <option value="mean-rank">Mean Rank</option>
                  <option value="rankograms">Rankograms</option>
                  <option value="other">Other</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <ChevronLeft className="h-4 w-4 text-gray-400 rotate-180" />
                </div>
              </div>
            </div>

            <div>
              <label htmlFor="transitivity-assessment" className="block text-sm font-medium text-gray-700 mb-1">
                Transitivity Assessment
                <Tooltip content="Describe how the assumption of transitivity will be assessed." />
              </label>
              <textarea
                id="transitivity-assessment"
                placeholder="E.g., Transitivity will be assessed by comparing the distribution of potential effect modifiers across treatment comparisons, including patient characteristics, intervention protocols, and study methodologies."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        )

      case "ipd-meta-analysis":
        return (
          <div className="space-y-4 border p-4 rounded-md bg-gray-50">
            <h4 className="font-medium text-gray-800">IPD Meta-Analysis Specific Details</h4>

            <div>
              <label htmlFor="data-acquisition" className="block text-sm font-medium text-gray-700 mb-1">
                Individual Patient Data Acquisition
                <Tooltip content="Describe how individual patient data will be obtained from original study authors or sponsors." />
              </label>
              <textarea
                id="data-acquisition"
                placeholder="E.g., Original study investigators will be contacted via email with a formal invitation to collaborate and share data. Data sharing agreements will be established to ensure patient confidentiality and appropriate data use."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="data-harmonization" className="block text-sm font-medium text-gray-700 mb-1">
                Data Harmonization Process
                <Tooltip content="Describe how variables from different studies will be standardized and harmonized." />
              </label>
              <textarea
                id="data-harmonization"
                placeholder="E.g., A common data model will be developed to standardize variable definitions, units of measurement, and outcome assessments across studies. Variable mappings will be created for each dataset and validated by the original study investigators."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="analysis-approach" className="block text-sm font-medium text-gray-700 mb-1">
                Analysis Approach
                <Tooltip content="Specify whether a one-stage or two-stage approach will be used for the IPD meta-analysis." />
              </label>
              <div className="relative">
                <select
                  id="analysis-approach"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="" disabled>
                    Select approach
                  </option>
                  <option value="one-stage">One-stage (Simultaneous analysis of all data)</option>
                  <option value="two-stage">Two-stage (Separate analysis of each study, then meta-analysis)</option>
                  <option value="both">Both approaches</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <ChevronLeft className="h-4 w-4 text-gray-400 rotate-180" />
                </div>
              </div>
            </div>

            <div>
              <label htmlFor="missing-data" className="block text-sm font-medium text-gray-700 mb-1">
                Missing Data Handling
                <Tooltip content="Describe how missing individual patient data will be handled in the analysis." />
              </label>
              <textarea
                id="missing-data"
                placeholder="E.g., Missing data will be examined for patterns. Multiple imputation will be used for variables with less than 20% missing values. Sensitivity analyses will be conducted to assess the impact of missing data assumptions."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="individual-covariates" className="block text-sm font-medium text-gray-700 mb-1">
                Individual-Level Covariates
                <Tooltip content="List the individual patient characteristics that will be included in the analyses." />
              </label>
              <textarea
                id="individual-covariates"
                placeholder="E.g., Age, sex, disease duration, disease severity, comorbidities, concomitant medications, baseline biomarker levels, and socioeconomic factors will be analyzed as potential effect modifiers."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="data-validation" className="block text-sm font-medium text-gray-700 mb-1">
                Data Validation Procedures
                <Tooltip content="Describe how the quality and integrity of the individual patient datasets will be validated." />
              </label>
              <textarea
                id="data-validation"
                placeholder="E.g., Datasets will be checked for internal consistency, outliers, and implausible values. Summary statistics will be calculated and compared with published results to verify data integrity. Discrepancies will be resolved through discussion with original investigators."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        )

      case "maic":
        return (
          <div className="space-y-4 border p-4 rounded-md bg-gray-50">
            <h4 className="font-medium text-gray-800">MAIC Specific Details</h4>

            <div>
              <label htmlFor="indirect-comparison" className="block text-sm font-medium text-gray-700 mb-1">
                Indirect Comparison Method
                <Tooltip content="Specify the specific approach for matching-adjusted indirect comparison." />
              </label>
              <div className="relative">
                <select
                  id="indirect-comparison"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={indirectComparisonMethod}
                  onChange={(e) => setIndirectComparisonMethod(e.target.value)}
                >
                  <option value="" disabled>
                    Select method
                  </option>
                  <option value="unanchored-maic">Unanchored MAIC</option>
                  <option value="anchored-maic">Anchored MAIC</option>
                  <option value="stc">Simulated Treatment Comparison (STC)</option>
                  <option value="other">Other</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <ChevronLeft className="h-4 w-4 text-gray-400 rotate-180" />
                </div>
              </div>
            </div>

            <div>
              <label htmlFor="ipd-source" className="block text-sm font-medium text-gray-700 mb-1">
                Individual Patient Data Source
                <Tooltip content="Describe the source of individual patient data for the index treatment." />
              </label>
              <textarea
                id="ipd-source"
                placeholder="E.g., Individual patient data from the XYZ trial (NCT12345678) will be used for the index treatment. This trial included 250 patients with condition A treated with Drug B."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="comparator-source" className="block text-sm font-medium text-gray-700 mb-1">
                Comparator Data Source
                <Tooltip content="Describe the source of aggregate data for the comparator treatment." />
              </label>
              <textarea
                id="comparator-source"
                placeholder="E.g., Published aggregate data from the ABC trial (NCT87654321) will be used for the comparator treatment. This includes summary baseline characteristics, efficacy outcomes, and safety data as reported in Smith et al. (2020)."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="matching-variables" className="block text-sm font-medium text-gray-700 mb-1">
                Matching Variables
                <Tooltip content="List the baseline characteristics that will be used for matching or adjustment." />
              </label>
              <textarea
                id="matching-variables"
                placeholder="E.g., Age, sex, disease duration, disease severity (measured by XYZ scale), prior treatment exposure, and presence of specific biomarkers will be used as matching variables."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label htmlFor="weighting-method" className="block text-sm font-medium text-gray-700 mb-1">
                Weighting Method
                <Tooltip content="Describe the method used to determine weights for individual patients in the IPD." />
              </label>
              <textarea
                id="weighting-method"
                placeholder="E.g., Entropy balancing will be used to derive weights that exactly match the means of baseline characteristics in the IPD to those reported for the comparator trial."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-900">Evidence Synthesis Study Details</h3>

      {/* Existing fields... */}

      {renderSubcategorySpecificFields()}

      {/* Existing fields... */}
    </div>
  )
}

export default EvidenceSynthesisForm

