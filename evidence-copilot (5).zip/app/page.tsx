"use client"

import { useState, useEffect, useCallback } from "react"
import {
  ChevronRight,
  Home,
  Search,
  BookOpen,
  FileText,
  FileCode,
  BookMarked,
  Send,
  Trash2,
  ChevronLeft,
  ChevronDown,
} from "lucide-react"
import Link from "next/link"
import InterventionalForm from "./components/InterventionalForm"
import NonInterventionalForm from "./components/NonInterventionalForm"
import NonClinicalForm from "./components/NonClinicalForm"
import EvidenceSynthesisForm from "./components/EvidenceSynthesisForm"
import Tooltip from "./components/Tooltip"

export default function EvidenceCoPilot() {
  const [activeTab, setActiveTab] = useState("Basic Info & Objectives")
  const [selectedCategory, setSelectedCategory] = useState("")
  const [selectedSubcategory, setSelectedSubcategory] = useState("")
  const [showAdvancedDetails, setShowAdvancedDetails] = useState(false)
  const [studyPhase, setStudyPhase] = useState("")
  const [isPostMarketingCommitment, setIsPostMarketingCommitment] = useState<boolean | null>(null)
  const [primaryResearchObjective, setPrimaryResearchObjective] = useState("")
  const [secondaryResearchObjectives, setSecondaryResearchObjectives] = useState("")
  const [exploratoryObjectives, setExploratoryObjectives] = useState("")
  const [arms, setArms] = useState([{ name: "", description: "" }])
  const [cohorts, setCohorts] = useState([{ name: "", description: "" }])
  const [selectedSecondaryType, setSelectedSecondaryType] = useState("")
  const [primaryDataStudyDesign, setPrimaryDataStudyDesign] = useState("")
  const [secondaryDataStudyDesign, setSecondaryDataStudyDesign] = useState("")
  const [primaryObjectivePlaceholder, setPrimaryObjectivePlaceholder] = useState("")
  const [secondaryObjectivesPlaceholder, setSecondaryObjectivesPlaceholder] = useState("")
  const [exploratoryObjectivesPlaceholder, setExploratoryObjectivesPlaceholder] = useState("")

  const tabs = [
    "Basic Info & Objectives",
    "Methodology",
    "Literature Search",
    "Upload documents",
    "Generate synopsis",
    "Review",
  ]

  const updateObjectivePlaceholders = useCallback(() => {
    switch (selectedCategory) {
      case "interventional":
        setPrimaryObjectivePlaceholder(
          "E.g., To evaluate the efficacy of Drug X in reducing symptoms of Condition Y compared to placebo over a 12-week period.",
        )
        setSecondaryObjectivesPlaceholder(
          "E.g., 1) To assess the safety profile of Drug X. 2) To evaluate quality of life improvements in patients receiving Drug X.",
        )
        setExploratoryObjectivesPlaceholder("E.g., To explore potential biomarkers associated with response to Drug X.")
        break
      case "non-interventional":
        if (selectedSubcategory === "primary-data") {
          setPrimaryObjectivePlaceholder(
            "E.g., To determine the incidence of Condition Z in patients exposed to Factor A over a 5-year period.",
          )
          setSecondaryObjectivesPlaceholder(
            "E.g., 1) To identify risk factors associated with Condition Z. 2) To describe the natural history of Condition Z.",
          )
          setExploratoryObjectivesPlaceholder(
            "E.g., To investigate potential gene-environment interactions in the development of Condition Z.",
          )
        } else if (selectedSubcategory === "secondary-data") {
          setPrimaryObjectivePlaceholder(
            "E.g., To assess the association between Treatment B and Outcome C using electronic health records from 2010-2020.",
          )
          setSecondaryObjectivesPlaceholder(
            "E.g., 1) To evaluate the impact of comorbidities on the effectiveness of Treatment B. 2) To compare the cost-effectiveness of Treatment B with standard care.",
          )
          setExploratoryObjectivesPlaceholder(
            "E.g., To explore temporal trends in the prescription patterns of Treatment B.",
          )
        } else {
          setPrimaryObjectivePlaceholder(
            "E.g., To characterize the natural history of Disease D using a combination of prospective data collection and retrospective chart review.",
          )
          setSecondaryObjectivesPlaceholder(
            "E.g., 1) To identify predictors of disease progression in Disease D. 2) To assess the impact of current treatment practices on patient outcomes.",
          )
          setExploratoryObjectivesPlaceholder(
            "E.g., To investigate the potential role of novel biomarkers in predicting treatment response in Disease D.",
          )
        }
        break
      case "non-clinical":
        switch (selectedSubcategory) {
          case "in-vitro":
            setPrimaryObjectivePlaceholder(
              "E.g., To investigate the mechanism of action of Compound E on Receptor F in a cell culture model.",
            )
            setSecondaryObjectivesPlaceholder(
              "E.g., 1) To determine the IC50 of Compound E. 2) To assess the specificity of Compound E for Receptor F compared to related receptors.",
            )
            setExploratoryObjectivesPlaceholder(
              "E.g., To explore potential off-target effects of Compound E using a panel of kinase assays.",
            )
            break
          case "in-vivo":
            setPrimaryObjectivePlaceholder(
              "E.g., To evaluate the efficacy of Drug G in reducing tumor growth in a mouse model of Cancer H.",
            )
            setSecondaryObjectivesPlaceholder(
              "E.g., 1) To assess the pharmacokinetics of Drug G in mice. 2) To evaluate the impact of Drug G on survival in the mouse model.",
            )
            setExploratoryObjectivesPlaceholder(
              "E.g., To investigate potential biomarkers of response to Drug G in tumor tissue samples.",
            )
            break
          case "ex-vivo":
            setPrimaryObjectivePlaceholder(
              "E.g., To assess the effect of Treatment I on tissue samples from patients with Condition J.",
            )
            setSecondaryObjectivesPlaceholder(
              "E.g., 1) To compare the response to Treatment I in tissues from different patient subgroups. 2) To evaluate the impact of Treatment I on tissue-specific biomarkers.",
            )
            setExploratoryObjectivesPlaceholder(
              "E.g., To explore the relationship between genetic polymorphisms and tissue response to Treatment I.",
            )
            break
          case "in-silico":
            setPrimaryObjectivePlaceholder(
              "E.g., To predict potential drug-drug interactions between Compound K and commonly prescribed medications using computational modeling.",
            )
            setSecondaryObjectivesPlaceholder(
              "E.g., 1) To identify structural features of Compound K that contribute to predicted interactions. 2) To assess the impact of genetic variants on predicted drug-drug interactions.",
            )
            setExploratoryObjectivesPlaceholder(
              "E.g., To explore novel chemical modifications that could reduce predicted drug-drug interactions while maintaining efficacy.",
            )
            break
          default:
            setPrimaryObjectivePlaceholder(
              "E.g., To investigate the pharmacological properties of Compound L in a relevant non-clinical model.",
            )
            setSecondaryObjectivesPlaceholder(
              "E.g., 1) To determine the optimal dose and schedule for Compound L. 2) To assess potential toxicities associated with Compound L.",
            )
            setExploratoryObjectivesPlaceholder(
              "E.g., To explore the potential of Compound L in combination with other therapeutic agents.",
            )
        }
        break
      case "evidence-synthesis":
        setPrimaryObjectivePlaceholder(
          "E.g., To systematically review and meta-analyze the efficacy and safety of Intervention M for treating Condition N in adult patients.",
        )
        setSecondaryObjectivesPlaceholder(
          "E.g., 1) To assess the quality of evidence for Intervention M. 2) To evaluate the heterogeneity of treatment effects across different patient subgroups.",
        )
        setExploratoryObjectivesPlaceholder(
          "E.g., To explore potential sources of bias in the existing literature on Intervention M.",
        )
        break
      default:
        setPrimaryObjectivePlaceholder("Enter the primary research objective or question your study aims to address.")
        setSecondaryObjectivesPlaceholder(
          "Enter any secondary research objectives or questions your study aims to address.",
        )
        setExploratoryObjectivesPlaceholder("Enter any exploratory or hypothesis-generating objectives for your study.")
    }
  }, [selectedCategory, selectedSubcategory])

  useEffect(() => {
    updateObjectivePlaceholders()
  }, [updateObjectivePlaceholders])

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category)
    setSelectedSubcategory("")
    setStudyPhase("")
    setIsPostMarketingCommitment(null)
    setArms([])
    setCohorts([])
    setSelectedSecondaryType("")
    setPrimaryDataStudyDesign("")
    setSecondaryDataStudyDesign("")
    updateObjectivePlaceholders()
  }

  const handleSubcategoryChange = (subcategory: string) => {
    setSelectedSubcategory(subcategory)
    setStudyPhase("")
    setIsPostMarketingCommitment(null)
    updateObjectivePlaceholders()
  }

  const renderCategoryForm = () => {
    switch (selectedCategory) {
      case "interventional":
        return (
          <InterventionalForm
            selectedSubcategory={selectedSubcategory}
            studyPhase={studyPhase}
            setStudyPhase={setStudyPhase}
            isPostMarketingCommitment={isPostMarketingCommitment}
            setIsPostMarketingCommitment={setIsPostMarketingCommitment}
          />
        )
      case "non-interventional":
        return (
          <>
            <NonInterventionalForm
              selectedSubcategory={selectedSubcategory}
              isPostMarketingCommitment={isPostMarketingCommitment}
              setIsPostMarketingCommitment={setIsPostMarketingCommitment}
              onSubcategoryChange={handleSubcategoryChange}
            />
          </>
        )
      case "non-clinical":
        return <NonClinicalForm selectedSubcategory={selectedSubcategory} />
      case "evidence-synthesis":
        return <EvidenceSynthesisForm selectedSubcategory={selectedSubcategory} />
      default:
        return null
    }
  }

  const validateForm = () => {
    if (!primaryResearchObjective.trim()) {
      alert("Please enter the primary research objective.")
      return false
    }

    // Add more validation checks here based on the selected category and subcategory
    if (
      selectedCategory === "non-interventional" &&
      selectedSubcategory === "secondary-data" &&
      !selectedSecondaryType
    ) {
      alert("Please select a secondary data subtype.")
      return false
    }

    return true
  }

  const handleGenerateSynopsis = () => {
    if (validateForm()) {
      // Proceed with synopsis generation
      console.log("Generating synopsis...")
      // Add your synopsis generation logic here
    }
  }

  const addArm = () => {
    setArms([...arms, { name: "", description: "" }])
  }

  const addCohort = () => {
    setCohorts([...cohorts, { name: "", description: "" }])
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Left Sidebar */}
      <div className="w-[316px] bg-white flex flex-col border-r border-gray-200">
        {/* Logo and Tagline */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center">
            <span className="text-red-600 text-2xl font-bold">E</span>
            <span className="text-black text-2xl font-bold">vidence</span>
          </div>
          <div className="flex items-center">
            <span className="text-red-600 text-2xl font-bold">C</span>
            <span className="text-black text-2xl font-bold">o</span>
            <span className="text-red-600 text-2xl font-bold">P</span>
            <span className="text-black text-2xl font-bold">ilot</span>
          </div>
          <p className="text-sm text-gray-600 mt-1">Accelerating evidence with GenAI</p>
        </div>

        {/* Navigation Menu */}
        <div className="flex-1 overflow-auto">
          <nav className="p-2">
            <Link href="#" className="flex items-center gap-3 text-blue-600 bg-blue-50 p-3 rounded-md mb-1">
              <Home className="h-5 w-5" />
              <span>Home</span>
            </Link>
            <Link href="#" className="flex items-center gap-3 text-gray-700 hover:bg-gray-100 p-3 rounded-md mb-1">
              <Search className="h-5 w-5" />
              <span>Literature Search</span>
            </Link>
            <Link href="#" className="flex items-center gap-3 text-gray-700 hover:bg-gray-100 p-3 rounded-md mb-1">
              <BookOpen className="h-5 w-5" />
              <span>SLR & Meta-analysis</span>
            </Link>
            <Link href="#" className="flex items-center gap-3 text-gray-700 hover:bg-gray-100 p-3 rounded-md mb-1">
              <FileText className="h-5 w-5" />
              <span>Synopsis Development</span>
            </Link>
            <Link href="#" className="flex items-center gap-3 text-gray-700 hover:bg-gray-100 p-3 rounded-md mb-1">
              <FileCode className="h-5 w-5" />
              <span>Protocol Development</span>
            </Link>
            <Link href="#" className="flex items-center gap-3 text-gray-700 hover:bg-gray-100 p-3 rounded-md mb-1">
              <BookMarked className="h-5 w-5" />
              <span>Publication Development</span>
            </Link>
          </nav>

          {/* Recent Chats */}
          <div className="p-4 mt-4">
            <h3 className="text-sm font-medium text-gray-500 mb-2">Recent chats</h3>
            <div className="space-y-2">
              {[
                "Question 3 lorem ipsum dolor sit amet consectetur",
                "Question 2 lorem ipsum dolor sit amet?",
                "Question 1 lorem ipsum dolor sit amet?",
              ].map((chat, index) => (
                <div key={index} className="flex items-center justify-between group">
                  <span className="text-sm text-gray-700 truncate">{chat}</span>
                  <button className="opacity-0 group-hover:opacity-100 transition-opacity">
                    <Trash2 className="h-4 w-4 text-gray-400 hover:text-gray-600" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* User Profile */}
        <div className="p-4 border-t border-gray-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-blue-600 flex items-center justify-center text-white">TD</div>
            <div>
              <p className="font-medium">Tommy De Kimpe</p>
              <p className="text-xs text-gray-500">tommydekimpe@jnj.com</p>
            </div>
          </div>
          <ChevronRight className="h-5 w-5 text-gray-400" />
        </div>

        {/* Footer */}
        <div className="p-4 text-xs text-gray-500 border-t border-gray-200">
          <p>Version 0.3.1</p>
          <p className="mt-1">
            For questions, suggestions or bug reports, please use the following{" "}
            <a href="#" className="text-blue-500 hover:underline">
              Feedback Form
            </a>
            .
          </p>
          <p className="mt-2 text-right text-red-600 font-bold">J&J</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Tabs */}
        <div className="bg-white border-b border-gray-200 px-8">
          <div className="flex">
            {tabs.map((tab) => (
              <button
                key={tab}
                className={`px-4 py-3 text-sm font-medium ${
                  activeTab === tab ? "text-blue-600 border-b-2 border-blue-600" : "text-gray-600 hover:text-gray-800"
                }`}
                onClick={() => setActiveTab(tab)}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Form Content */}
        <div className="flex-1 p-8 overflow-auto">
          <h1 className="text-2xl font-bold text-gray-800 mb-8">Basic Info & Objectives</h1>

          <div className="space-y-6 max-w-3xl">
            {/* Study Name */}
            <div>
              <label htmlFor="study-name" className="block text-sm font-medium text-gray-700 mb-1">
                Study name
              </label>
              <input
                type="text"
                id="study-name"
                placeholder="Enter study name"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Research Category */}
            <div>
              <label htmlFor="research-category" className="block text-sm font-medium text-gray-700 mb-1">
                Research category
              </label>
              <div className="relative">
                <select
                  id="research-category"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={selectedCategory}
                  onChange={(e) => handleCategoryChange(e.target.value)}
                >
                  <option value="" disabled>
                    Select research category
                  </option>
                  <option value="interventional">Interventional</option>
                  <option value="non-interventional">Non-Interventional</option>
                  <option value="non-clinical">Non-clinical</option>
                  <option value="evidence-synthesis">Evidence Synthesis</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <ChevronLeft className="h-4 w-4 text-gray-400 rotate-180" />
                </div>
              </div>
            </div>

            {/* Data Collection Type - Only show for non-interventional category */}
            {selectedCategory === "non-interventional" && (
              <div>
                <label htmlFor="data-collection-type" className="block text-sm font-medium text-gray-700 mb-1">
                  Data Collection Type
                  <Tooltip content="Select whether you will collect new data (Primary) or use existing data (Secondary) for your study." />
                </label>
                <div className="relative">
                  <select
                    id="data-collection-type"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={selectedSubcategory}
                    onChange={(e) => handleSubcategoryChange(e.target.value)}
                  >
                    <option value="" disabled>
                      Select data collection type
                    </option>
                    <option value="primary-data">Primary Data Collection</option>
                    <option value="secondary-data">Secondary Data Analysis</option>
                    <option value="primary-and-secondary">Primary and Secondary</option>
                  </select>
                  <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                    <ChevronLeft className="h-4 w-4 text-gray-400 rotate-180" />
                  </div>
                </div>
                {selectedSubcategory && (
                  <p className="mt-2 text-sm text-gray-600">
                    {selectedSubcategory === "primary-data" &&
                      "Data collected directly for the purpose of the study through mechanisms like surveys, interviews, or direct measurements from patients or populations."}
                    {selectedSubcategory === "secondary-data" &&
                      "Use of pre-existing datasets collected for other purposes but repurposed for the current research objectives (e.g., electronic health records, claims databases, registries)."}
                    {selectedSubcategory === "primary-and-secondary" &&
                      "A combination of newly collected data and analysis of existing datasets to address the research objectives."}
                  </p>
                )}
              </div>
            )}

            {/* Subcategory Selection */}
            {selectedCategory && selectedCategory !== "non-interventional" && (
              <div>
                <label htmlFor="research-subcategory" className="block text-sm font-medium text-gray-700 mb-1">
                  {selectedCategory === "interventional"
                    ? "Trial Type"
                    : selectedCategory === "non-clinical"
                      ? "Study Model"
                      : selectedCategory === "evidence-synthesis"
                        ? "Type of Evidence Synthesis"
                        : "Subcategory"}
                </label>
                <div className="relative">
                  <select
                    id="research-subcategory"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={selectedSubcategory}
                    onChange={(e) => handleSubcategoryChange(e.target.value)}
                  >
                    <option value="" disabled>
                      {selectedCategory === "interventional"
                        ? "Select trial type"
                        : selectedCategory === "non-clinical"
                          ? "Select model"
                          : selectedCategory === "evidence-synthesis"
                            ? "Select type of evidence synthesis"
                            : "Select subcategory"}
                    </option>

                    {selectedCategory === "interventional" && (
                      <>
                        <option value="traditional-rct">Traditional RCT</option>
                        <option value="pragmatic-study">Pragmatic Study</option>
                        <option value="adaptive-trial">Adaptive Trial</option>
                        <option value="basket-trial">Basket Trial</option>
                        <option value="umbrella-trial">Umbrella Trial</option>
                        <option value="non-randomized">Non-Randomized Study</option>
                      </>
                    )}

                    {selectedCategory === "non-clinical" && (
                      <>
                        <option value="in-vitro">In Vitro</option>
                        <option value="in-vivo">In Vivo</option>
                        <option value="ex-vivo">Ex Vivo</option>
                        <option value="in-silico">In Silico</option>
                      </>
                    )}

                    {selectedCategory === "evidence-synthesis" && (
                      <>
                        <option value="systematic-review">Systematic Review</option>
                        <option value="meta-analysis">Meta-Analysis</option>
                        <option value="network-meta-analysis">Network Meta-Analysis</option>
                        <option value="maic">MAIC</option>
                        <option value="ipd-analysis">IPD Analysis</option>
                        <option value="post-hoc-analysis">Post-hoc Analysis</option>
                      </>
                    )}
                  </select>
                  <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                    <ChevronLeft className="h-4 w-4 text-gray-400 rotate-180" />
                  </div>
                </div>
              </div>
            )}

            {/* Primary Research Objective */}
            <div>
              <label htmlFor="primary-objective" className="block text-sm font-medium text-gray-700 mb-1">
                Primary Research Objective
                <Tooltip content="The main question your study aims to answer or the primary outcome you want to measure." />
              </label>
              <textarea
                id="primary-objective"
                value={primaryResearchObjective}
                onChange={(e) => setPrimaryResearchObjective(e.target.value)}
                placeholder={primaryObjectivePlaceholder}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Render the appropriate form based on the selected category */}
            {renderCategoryForm()}

            {/* Advanced Details */}
            <div className="mt-8 border border-gray-200 rounded-md">
              <button
                onClick={() => setShowAdvancedDetails(!showAdvancedDetails)}
                className="w-full px-4 py-2 text-left bg-gray-50 hover:bg-gray-100 transition-colors flex items-center justify-between"
              >
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Advanced Details (Optional)</h3>
                  <p className="text-sm text-gray-600">
                    Provide more specific information for a more precise and comprehensive AI-generated synopsis.
                  </p>
                </div>
                <ChevronDown
                  className={`h-5 w-5 text-gray-500 transition-transform ${showAdvancedDetails ? "rotate-180" : ""}`}
                />
              </button>
              {showAdvancedDetails && (
                <div className="p-4 space-y-4 border-t border-gray-200">
                  <div>
                    <label htmlFor="secondary-objectives" className="block text-sm font-medium text-gray-700 mb-1">
                      Secondary Research Objectives
                      <Tooltip content="Additional outcomes or questions your study aims to address, beyond the primary objective." />
                    </label>
                    <textarea
                      id="secondary-objectives"
                      value={secondaryResearchObjectives}
                      onChange={(e) => setSecondaryResearchObjectives(e.target.value)}
                      placeholder={secondaryObjectivesPlaceholder}
                      rows={4}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label htmlFor="exploratory-objectives" className="block text-sm font-medium text-gray-700 mb-1">
                      Exploratory Objectives
                      <Tooltip content="Hypothesis-generating objectives that may lead to future research questions." />
                    </label>
                    <textarea
                      id="exploratory-objectives"
                      value={exploratoryObjectives}
                      onChange={(e) => setExploratoryObjectives(e.target.value)}
                      placeholder={exploratoryObjectivesPlaceholder}
                      rows={4}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  {/* Interventional: Study Arms */}
                  {selectedCategory === "interventional" && (
                    <div>
                      <h4 className="text-md font-medium text-gray-800 mb-2">Study Arms</h4>
                      {arms.map((arm, index) => (
                        <div key={index} className="mb-4 p-4 border border-gray-200 rounded-md">
                          <label className="block text-sm font-medium text-gray-700 mb-1">Arm {index + 1} Name</label>
                          <input
                            type="text"
                            value={arm.name}
                            onChange={(e) => {
                              const newArms = [...arms]
                              newArms[index].name = e.target.value
                              setArms(newArms)
                            }}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 mb-2"
                          />
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Arm {index + 1} Description
                          </label>
                          <textarea
                            value={arm.description}
                            onChange={(e) => {
                              const newArms = [...arms]
                              newArms[index].description = e.target.value
                              setArms(newArms)
                            }}
                            rows={3}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                      ))}
                      <button
                        onClick={addArm}
                        className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                      >
                        Add Study Arm
                      </button>
                    </div>
                  )}

                  {/* Non-Interventional: Cohorts (for primary data) */}
                  {selectedCategory === "non-interventional" && selectedSubcategory === "primary-data" && (
                    <div>
                      <h4 className="text-md font-medium text-gray-800 mb-2">Study Cohorts</h4>
                      {cohorts.map((cohort, index) => (
                        <div key={index} className="mb-4 p-4 border border-gray-200 rounded-md">
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Cohort {index + 1} Name
                          </label>
                          <input
                            type="text"
                            value={cohort.name}
                            onChange={(e) => {
                              const newCohorts = [...cohorts]
                              newCohorts[index].name = e.target.value
                              setCohorts(newCohorts)
                            }}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 mb-2"
                          />
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Cohort {index + 1} Description
                          </label>
                          <textarea
                            value={cohort.description}
                            onChange={(e) => {
                              const newCohorts = [...cohorts]
                              newCohorts[index].description = e.target.value
                              setCohorts(newCohorts)
                            }}
                            rows={3}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                      ))}
                      <button
                        onClick={addCohort}
                        className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                      >
                        Add Study Cohort
                      </button>
                    </div>
                  )}

                  <div>
                    <label htmlFor="additional-info" className="block text-sm font-medium text-gray-700 mb-1">
                      Additional Information
                    </label>
                    <textarea
                      id="additional-info"
                      placeholder="Any additional details about your study design?"
                      rows={4}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Generate Synopsis Button */}
            <div className="mt-8 flex justify-end">
              <button
                onClick={handleGenerateSynopsis}
                className="bg-blue-600 text-white px-4 py-2 rounded-md flex items-center gap-2 hover:bg-blue-700 transition-colors"
              >
                Generate Synopsis
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Right Sidebar - AI Assistant */}
      <div className="w-[300px] bg-white border-l border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 rounded-full bg-gray-200 flex items-center justify-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-gray-400"
              >
                <circle cx="12" cy="12" r="10" />
                <path d="M12 16v-4M12 8h.01" />
              </svg>
            </div>
            <h3 className="font-medium">AI assistant</h3>
          </div>
        </div>

        <div className="flex-1 p-4 overflow-auto">
          <div className="bg-blue-50 rounded-lg p-4 mb-4">
            <h4 className="font-medium mb-2">What can I help you with?</h4>
            <ul className="list-disc pl-5 space-y-1 text-sm">
              <li>Upload and analyze files</li>
              <li>Answer questions and generate ideas</li>
            </ul>
            <p className="text-sm mt-2">Let's develop a comprehensive Synopsis together!</p>
          </div>
        </div>

        <div className="p-4 border-t border-gray-200">
          <div className="relative">
            <input
              type="text"
              placeholder="What can I help you with?"
              className="w-full pl-8 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <div className="absolute left-2 top-1/2 transform -translate-y-1/2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-gray-400"
              >
                <circle cx="12" cy="12" r="10" />
                <path d="M12 16v-4M12 8h.01" />
              </svg>
            </div>
            <button className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-blue-600 text-white p-1 rounded">
              <Send className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

